<?php

namespace FoxSolution\AutoContent\Contracts;

interface OpenAiInterface
{
    public function initInstance();
}
