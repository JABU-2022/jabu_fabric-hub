<?php

if (! defined('AUTOCONTENT_FILTER_ADD_SUPPORT_FIELDS')) {
    define('AUTOCONTENT_FILTER_ADD_SUPPORT_FIELDS', 'autocontent_filter_add_support_fields');
}
if (! defined('AUTOCONTENT_ACTION_ADD_ENTITY_TYPE')) {
    define('AUTOCONTENT_ACTION_ADD_ENTITY_TYPE', 'autocontent_action_add_entity_type');
}
