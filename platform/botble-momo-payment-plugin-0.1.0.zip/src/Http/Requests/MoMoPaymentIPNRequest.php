<?php

namespace Binjuhor\MoMo\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MoMoPaymentIPNRequest extends FormRequest
{
    public function rules(): array
    {
        return [];
    }
}
