<?php

namespace Binjuhor\MoMo\Http\Requests;

use Botble\Support\Http\Requests\Request;

class MoMoPaymentCallbackRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
