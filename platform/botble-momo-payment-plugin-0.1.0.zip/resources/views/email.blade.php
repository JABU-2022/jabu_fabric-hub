<strong>{{ trans('plugins/momo::momo.payment_details') }}: </strong>
@include('plugins/momo::detail', compact('payment'))
