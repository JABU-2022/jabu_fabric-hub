<?php

if (! defined('MOMO_PAYMENT_METHOD_NAME')) {
    define('MOMO_PAYMENT_METHOD_NAME', 'momo');
}
