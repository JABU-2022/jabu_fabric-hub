<?php

return [
    'sandbox' => env('MOMO_DOMAIN_API_SANDBOX','https://test-payment.momo.vn'),
    'production' => env('MOMO_DOMAIN_API_PRODUCT','https://payment.momo.vn'),
];
