## MoMo pay for Botble CMS

This plugin helps you integrate MoMo pay into Botble CMS eCommerce.

### Installation

- Download & unzip the module
- Copy & paste to `platform/plugins/momo` folder
- Go to Admin Panel -> Plugins and activate the MoMo pay plugin.
- Go to Admin Panel -> Settings -> Payment Gateways and config MoMo pay.


### License

This plugin is released under the [MIT license](LICENSE).

### Contact

If you have any question or idea, don't hesitate to contact us at [hi@binjuhor.com](mailto:hi@binjuhor.com)

