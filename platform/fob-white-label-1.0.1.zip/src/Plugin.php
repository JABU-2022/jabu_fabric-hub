<?php

namespace FriendsOfBotble\WhiteLabel;

use Botble\PluginManagement\Abstracts\PluginOperationAbstract;

class Plugin extends PluginOperationAbstract
{
    //
}
