<?php

return [
    [
        'name' => 'White Label Settings',
        'flag' => 'white-label.settings',
    ],
];
