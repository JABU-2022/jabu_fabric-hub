# Changelog

All notable changes to `fob-white-label` will be documented in this file

## 1.0.1 - 2024-04-04

- [Remove] CMS detector option because it doesn't work as expected.

## 1.0.0 - 2024-04-04

- First release 🥳
